/* Generated automatically by the program `./gcov-iov'
   from `4.1.2 (4 1) and p (p)'.  */

#define GCOV_VERSION ((gcov_unsigned_t)0x34303170)  /* 401p */
